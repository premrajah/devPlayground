$(document).ready(function(){

  











}); // end document.ready